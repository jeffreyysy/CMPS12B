//Jeffrey Yeung
//jeyyeung
//CMPS 12B
//February 3, 2018
//KeyNotFoundException for the delete method

public class KeyNotFoundException extends RuntimeException{
  public KeyNotFoundException(String s){
    super(s);
  }
}
