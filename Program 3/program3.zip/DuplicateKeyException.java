//Jeffrey Yeung
//jeyyeung
//CMPS 12B
//February 3, 2018
//DuplicateKeyException for the insert method

public class DuplicateKeyException extends RuntimeException{
  public DuplicateKeyException(String s) {
    super(s);
  }
}
