Jeffrey Yeung
jeyyeung
CMPS 12B
March 12, 2018
README file

1. Dictionary.c
2. Dictionary.h
3. DictionaryTest.c
4. DictionaryClient.c
5. Makefile
6. README.txt
