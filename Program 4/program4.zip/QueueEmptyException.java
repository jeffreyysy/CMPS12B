//Jeffrey Yeung
//jeyyeung
//CMPS 12B
//February 23, 2018
//excpetion class

public class QueueEmptyException extends RuntimeException {
  public QueueEmptyException(String s) {
    super(s);
  }
}
